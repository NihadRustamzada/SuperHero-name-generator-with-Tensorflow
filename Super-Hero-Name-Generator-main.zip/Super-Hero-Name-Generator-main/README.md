# Super Hero Name Generator
Natural language generation with a deep learning model implemented in Tensorflow.  
This model genarates super heroes names based on few input characters given by the user.